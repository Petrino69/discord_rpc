Config = {}

Config.ApplicationID = "1271498147603943579" -- z Discord Developer Portalu
Config.LargeImage = "chillside_rp" -- název obrázku/GIFu nahraného na appce
Config.LargeText = "|🌅𝗖𝗵𝗶𝗹𝗹𝗦𝗶𝗱𝗲 𝗥𝗣🌅| " -- text po najetí na obrázek
Config.SmallImage = "icon_small"
Config.SmallText = "FiveM fun begins"

Config.Buttons = {
    {
        label = "🌐Discord",
        url = "https://dsc.gg/chillside-rp"
    },
    {
        label = "🎮Fivem",
        url = "https://cfx.re/join/pmam4a"
    }
}
