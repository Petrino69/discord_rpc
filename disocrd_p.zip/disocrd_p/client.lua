Citizen.CreateThread(function()
    while true do
        -- Základní info
        local playerName = GetPlayerName(PlayerId())
        local playerId = GetPlayerServerId(PlayerId())
        local players = #GetActivePlayers()

        -- Rich Presence setup
        SetDiscordAppId(Config.ApplicationID)
        SetDiscordRichPresenceAsset(Config.LargeImage)
        SetDiscordRichPresenceAssetText(Config.LargeText)

        SetDiscordRichPresenceAssetSmall(Config.SmallImage)
        SetDiscordRichPresenceAssetSmallText(Config.SmallText)

        SetRichPresence(("👤 %s | ID: %s | 👥 %s hráčů"):format(playerName, playerId, players))

        -- Tlačítka
        for i, btn in ipairs(Config.Buttons) do
            SetDiscordRichPresenceAction(i - 1, btn.label, btn.url)
        end

        -- Obnova každých 60 sekund
        Citizen.Wait(60000)
    end
end)
