fx_version 'cerulean'
game 'gta5'

author 'ChilsideRP'
description 'Moderní Discord Rich Presence pro ESX server'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}
